package com.eon.smartpen;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.eon.smartpen.Model.DateIndexItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by taeya on 2017-10-17.
 */

public class MenuActivity extends AppCompatActivity{
    private static final String TAG = "MenuActivity";
    private ListView mLvMyItems;
    private ArrayAdapter<String> idAdapter = null;
    private ArrayList<String> idString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        mLvMyItems = (ListView) findViewById(R.id.lvDrawings2);

        idString= new ArrayList<String>();
        idString.add("이규호");idString.add("id-765432");idString.add("id-123144");
        idAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, idString); // 기본 1줄 짜리 list
        //mAdapter = new ListViewAdapter(this, android.R.layout.simple_list_item_2, hList); // 기본 1줄 짜리 list
        mLvMyItems.setAdapter(idAdapter);
        //View backrgb = new View(mLvMyItems.getChildAt(0).setBackgroundColor(Color.YELLOW);
        mLvMyItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item = idAdapter.getItem(0);
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
