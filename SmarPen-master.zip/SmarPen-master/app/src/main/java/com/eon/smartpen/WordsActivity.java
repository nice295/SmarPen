package com.eon.smartpen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.eon.smartpen.Model.DateIndexItem;
import com.eon.smartpen.Model.DateIndexItem;
import com.eon.smartpen.Model.DrawingsItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Created by mjk27 on 2017-08-01.
 */

public class WordsActivity extends AppCompatActivity {

    private static final String TAG = "WordsActivity";

   // private ArrayList<DrawingsItem> mMyItemArray;

    private ListView mLvMyItems;
    private ListViewAdapter mAdapter = null;
    private ArrayList<DateIndexItem> mMyItemArray;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);


        Intent intent = getIntent();
        final String index = intent.getExtras().getString("index"); // intent 값 수신하고
        Log.i(TAG, "Index: " + index);

        mLvMyItems = (ListView) findViewById(R.id.lvWords);
        mMyItemArray = new ArrayList<DateIndexItem>();
        mAdapter = new ListViewAdapter(this, android.R.layout.simple_list_item_1, mMyItemArray); // 기본 1줄 짜리 list
        mLvMyItems.setAdapter(mAdapter);

        //mMyItemArray = new ArrayList<DrawingsItem>();

        mDatabase = FirebaseDatabase.getInstance().getReference();
        Query myTopPostsQuery = mDatabase.child("dates").child(index).child("wordsIndex"); // wordindex와 word 사용 차이 word는 x, y
        myTopPostsQuery.addValueEventListener // 데이터 읽고 변경 수신 대기?
                (
                        new ValueEventListener() // 변경사항 읽고 수신 대기
                        {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                mMyItemArray.clear();

                                if (dataSnapshot.getChildrenCount() != 0) {
                                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                        DateIndexItem item = postSnapshot.getValue(DateIndexItem.class);
                                        mMyItemArray.add(item);

                                        Log.d(TAG, "Loading Index: " + item.getIndex());
                                    }
                                    mAdapter.notifyDataSetChanged(); // 새로운 데이터를 listview로? --> 쓰레드 사용?
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Log.w(TAG, "words:onCancelled", databaseError.toException()); //읽기 취소? 실패?
                            }
                        }
                );

        mLvMyItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                DateIndexItem item = mAdapter.getItem().get(i);

                Intent intent = new Intent(getApplicationContext(), DrawingsActivity.class);

                intent.putExtra("index1", index);
                intent.putExtra("index2", item.getIndex());
                // words/<index>/...

                startActivity(intent);
            }
        });
    }


    private class ListViewAdapter extends ArrayAdapter<DateIndexItem> {
        private ArrayList<DateIndexItem> items;

        public ListViewAdapter(Context context, int textViewResourceId, ArrayList<DateIndexItem> items) {
            super(context, textViewResourceId, items);
            this.items = items;
        }

        public class ViewHolder {
            public TextView tvTime;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ListViewAdapter.ViewHolder viewHolder;

            Log.d(TAG, "position: " + position);

            DateIndexItem item = items.get(position);

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.layout_item_list_item, parent, false);

                viewHolder = new ListViewAdapter.ViewHolder();
                viewHolder.tvTime = (TextView) convertView.findViewById(R.id.tvTime);

                convertView.setTag(viewHolder);
            }
            else {
                viewHolder = (ListViewAdapter.ViewHolder) convertView.getTag();

            }

            Log.d(TAG, "Time: " + item.getIndex());
            viewHolder.tvTime.setText(String.valueOf(item.getIndex()));

            return convertView;
        }

        public ArrayList<DateIndexItem> getItem() {
            return this.items;
        }
    }
}
