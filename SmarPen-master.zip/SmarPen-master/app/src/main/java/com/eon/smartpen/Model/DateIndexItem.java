package com.eon.smartpen.Model;

/**
 * Created by mjk27 on 2017-08-01.
 */

public class DateIndexItem {
    public String index;

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public DateIndexItem(String index) {
        this.index = index;
    }

    public DateIndexItem() {
    }
}
