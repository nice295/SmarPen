package com.eon.smartpen.Model;

/**
 * Created by taeya on 2017-10-26.
 */

public class MemIndexItem {
    public String index;
    public String time;

    public MemIndexItem() {
        this.time="0";
        this.index="0";
    }


    public MemIndexItem(String time, String index) {
        this.time = time;
        this.index = index;
    }

    public String getIndex() {return index;}

    public String getTime() {return time;}

    public void setTime(String time) {
        this.time = time;
    }
    public void setIndex(String index) {
        this.index = index;
    }
}
