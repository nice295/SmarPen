package com.eon.smartpen;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Display;
import android.view.animation.AccelerateDecelerateInterpolator;

import com.eftimoff.androipathview.PathView;
import com.eon.smartpen.Model.DrawingsItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static java.lang.Math.abs;


public class DrawingsActivity extends AppCompatActivity {
    public static final int Limit = 40000;
    private int height; private int width;
    private static final String TAG = "DrawingsActivity";
    private DatabaseReference mDatabase;
    private ArrayList<DrawingsItem> mMyItemArray;
    private int minX=Limit;private int maxX=Limit;
    private int minY=Limit;private int maxY=Limit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        height = size.y-10;
        width = size.x-10;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawing);
        Intent intent = getIntent();
        final String index1 = intent.getExtras().getString("index1");
        final String index2 = intent.getExtras().getString("index2");
        Log.i(TAG, "hhheight " + height);
        Log.i(TAG, "width " + width);

        mMyItemArray = new ArrayList<DrawingsItem>();

        mDatabase = FirebaseDatabase.getInstance().getReference();

        Query myTopPostsQuery = mDatabase.child("dates").child(index1).child("words").child(index2);

        myTopPostsQuery.addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        mMyItemArray.clear();

                        if (dataSnapshot.getChildrenCount() != 0) {
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                DrawingsItem item = postSnapshot.getValue(DrawingsItem.class);

                              //  Log.i(TAG, "Timex: " + item.getTime());
                              //  Log.i(TAG, "X: " + item.getX());
                              //  Log.i(TAG, "Y: " + item.getY());

                                mMyItemArray.add(item);
                                if(minX==Limit){
                                    minX = mMyItemArray.get(0).getX();
                                    minY = mMyItemArray.get(0).getY();
                                    maxX = mMyItemArray.get(0).getX();
                                    maxY = mMyItemArray.get(0).getY();
                                }else{

                                    minX=minX>item.getX()?item.getX():minX;
                                    minY=minY>item.getY()?item.getY():minY;
                                    maxX=maxX<item.getX()?item.getX():maxX;
                                    maxY=maxY<item.getY()?item.getY():maxY;
                                }
                            }
                            // 핸드폰 최대 크기에 대한 비중
                            drawText();
                         }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.w(TAG, "words:onCancelled", databaseError.toException());
                    }
                }
        );
    }

    private void drawText() {

        final PathView pathView = (PathView) findViewById(R.id.pathView);

        final Path path = makePenPath();
        pathView.setPath(path);
        pathView.setFillAfter(true);
        pathView.setPathColor(Color.BLUE);

        pathView.getSequentialPathAnimator()
                .delay(300)
                .duration(500)
                .interpolator(new AccelerateDecelerateInterpolator())
                .start();
    }

    // how to divide paths.
    private Path makePenPath() {
        final Path path = new Path();
        Log.i(TAG, "minx" + minX);
        Log.i(TAG, "miny" + minY);
        Log.i(TAG, "maxx" + maxX);
        Log.i(TAG, "maxy" + maxY);
        path.moveTo(abs(mMyItemArray.get(0).getX()), abs(mMyItemArray.get(0).getY()+10));
        for (int idx = 0; idx < mMyItemArray.size(); idx++) {
            int valueX = abs(mMyItemArray.get(idx).getX());
            int valueY = abs(mMyItemArray.get(idx).getY());
       //   path.moveTo(mMyItemArray.get(idx).getX(), mMyItemArray.get(idx).getY());
            path.lineTo(valueX, valueY);
        }
        path.moveTo(abs(mMyItemArray.get(mMyItemArray.size()-1).getX())
                    , abs(mMyItemArray.get(mMyItemArray.size()-1).getY()));
        path.close();
        return path;
    }

    private int mapHeightPath(int value){
        return height*(value - minY) / (maxY - minY);
    }

    private int mapWidthPath(int value){
       return width*(value - minX) / (maxX - minX);
    }
}
