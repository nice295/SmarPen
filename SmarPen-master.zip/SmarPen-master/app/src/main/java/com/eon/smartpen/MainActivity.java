package com.eon.smartpen;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.eon.smartpen.Model.DateIndexItem;
import com.eon.smartpen.Model.DrawingsItem;
import com.eon.smartpen.Model.MemIndexItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;


public class MainActivity extends AppCompatActivity {
    static String str;
    private static final String TAG = "MainActivity";
    Switch aSwitch;
    private ListView mLvMyItems;
    private ListViewAdapter mAdapter = null;
    private ArrayList<MemIndexItem> m_ItemList;
    private DatabaseReference mDatabase;
    private int _change=0;
    private MemIndexItem m_item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m_item =new MemIndexItem();
        aSwitch = (Switch) findViewById(R.id.switch1);
        mLvMyItems = (ListView) findViewById(R.id.lvDrawings);
        m_ItemList = new ArrayList<MemIndexItem>();
        mAdapter = new ListViewAdapter(this,R.layout.layout_item_list_memo, m_ItemList); // 기본 1줄 짜리 list
        //mAdapter = new ListViewAdapter(this, android.R.layout.simple_list_item_2, hList); // 기본 1줄 짜리 list
        mLvMyItems.setAdapter(mAdapter);

        mDatabase = FirebaseDatabase.getInstance().getReference(); //DatabaseReference 가져오기
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    Toast.makeText(MainActivity.this, "알람을 중지합니다.", Toast.LENGTH_SHORT).show();
                    _change = 0;
                } else {
                    Toast.makeText(MainActivity.this, "기록을 알려줍니다.", Toast.LENGTH_SHORT).show();
                    _change = 1;
                }
            }
        });


        Query myTopPostsQuery = mDatabase.child("dateIndex"); // wordindex와 word 사용 차이 word는 x, y
        myTopPostsQuery.addValueEventListener // 데이터 읽고 변경 수신 대기?
                (
                new ValueEventListener() // 변경사항 읽고 수신 대기
                {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        m_ItemList.clear();
                        Intent intent = new Intent(MainActivity.this, PopUpService.class);
                        if(_change ==0) {
                            startService(intent);
                        }else{
                            stopService(intent);
                        }
                        if (dataSnapshot.getChildrenCount() != 0) {
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                MemIndexItem item = postSnapshot.getValue(MemIndexItem.class);
                                System.out.println("print+++++++++"+item.index+"--------"+item.time);
                                m_item.setIndex(item.getIndex());
                                m_item.setTime(item.getTime());
                                m_ItemList.add(item);
                            }
                            mAdapter.notifyDataSetChanged(); // 새로운 데이터를 listview로? --> 쓰레드 사용?
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.w(TAG, "words:onCancelled", databaseError.toException()); //읽기 취소? 실패?
                    }
                }
        );

        mLvMyItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                MemIndexItem item = mAdapter.getItem().get(i);

                Intent intent = new Intent(getApplicationContext(), WordsActivity.class);
                intent.putExtra("index", item.getIndex());
                // words/<index>/...

                startActivity(intent);
            }
        });
    }

    private class ListViewAdapter extends ArrayAdapter<MemIndexItem> {
        private ArrayList<MemIndexItem> items;

        public ListViewAdapter(Context context, int textViewResourceId, ArrayList<MemIndexItem> items) {
            super(context, textViewResourceId, items);
            this.items = items;
        }

        public class ViewHolder {
            public TextView tvDate;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            MemIndexItem item = items.get(position);

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.layout_item_list_memo, null);
            }
            if(item != null){
                TextView tt = (TextView) convertView.findViewById(R.id.toptext);
                TextView bt = (TextView) convertView.findViewById(R.id.bottomtext);
                if(tt != null){
                    tt.setText("#"+item.getTime());
                }
                if(bt != null){
                    bt.setText("생성시간: "+item.getIndex());
                }
            }
            return convertView;
        }

        public ArrayList<MemIndexItem> getItem() {
            return this.items;
        }
    }

}
